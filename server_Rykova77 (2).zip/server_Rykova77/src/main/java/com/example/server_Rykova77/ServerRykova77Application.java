package com.example.server_Rykova77;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerRykova77Application {

	public static void main(String[] args) {
		SpringApplication.run(ServerRykova77Application.class, args);
	}

}
