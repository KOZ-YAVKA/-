/* ============================================================
 *  БАЗА ТОВАРОВ
 * ============================================================ */
const products = [
    { id: 1, name: "Кровать Minimalist Linen Soft", cat: "beds", catName: "Кровати", price: 54000, tag: "Хит продаж", img: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=600&q=80", desc: "Двуспальная кровать с мягким изголовьем из натурального льна.", specs: { "Материал": "Массив дуба", "Размер": "160×200 / 180×200 см", "Изголовье": "Лён, 4 цвета", "Гарантия": "5 лет" } },
    { id: 2, name: "Кровать Velvet Elegance Gray", cat: "beds", catName: "Кровати", price: 68000, tag: "Новинка", img: "https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=600&q=80", desc: "Кровать с высоким бархатным изголовьем.", specs: { "Материал": "Берёза + велюр", "Размер": "160×200 см", "Цвет": "Серый", "Гарантия": "5 лет" } },
    { id: 3, name: "Кровать Nordik Solid Oak Frame", cat: "beds", catName: "Кровати", price: 72000, tag: "Премиум", img: "https://plus.unsplash.com/premium_photo-1684445035187-c4bc7c96bc5d?fm=jpg&q=60&w=3000&auto=format&fit=crop", desc: "Кровать из цельного массива дуба.", specs: { "Материал": "Дуб", "Размер": "160×200 см", "Покрытие": "Масло-воск", "Гарантия": "7 лет" } },
    { id: 4, name: "Кровать Floating Light Beige", cat: "beds", catName: "Кровати", price: 89000, tag: "Хит", img: "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=600&q=80", desc: "Кровать «парящего» типа с подсветкой снизу.", specs: { "Материал": "Ясень", "Размер": "180×200 см", "Подсветка": "LED", "Гарантия": "5 лет" } },
    { id: 5, name: "Кровать Loft Metal & Ash Wood", cat: "beds", catName: "Кровати", price: 49000, tag: "SALE", img: "https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?auto=format&fit=crop&w=600&q=80", desc: "Кровать в стиле лофт.", specs: { "Материал": "Металл", "Размер": "160×200 см", "Отделка": "Краска", "Гарантия": "3 года" } },
    { id: 6, name: "Тумба прикроватная WoodLines", cat: "nightstands", catName: "Тумбы", price: 14500, tag: "Хит продаж", img: "https://images.unsplash.com/photo-1637277810826-d79eac657158?fm=jpg&q=60&w=3000&auto=format&fit=crop", desc: "Тумба с двумя ящиками.", specs: { "Материал": "Дуб", "Размер": "45×40×55 см", "Ящики": "2 шт.", "Гарантия": "5 лет" } },
    { id: 7, name: "Тумба Подвесная Slim Oak", cat: "nightstands", catName: "Тумбы", price: 11800, tag: "Новинка", img: "https://media.istockphoto.com/id/2215369853/photo/a-minimalist-elegant-modern-bedroom-featuring-a-sleek-bed-natural-color-tones-and-a-bright.webp?a=1&b=1&s=612x612&w=0&k=20&c=Ek5xH07RmKZ0RcJt62BZQwGqtga1CtrY28Sbj-EJoUE=", desc: "Подвесная тумба без ножек.", specs: { "Материал": "Ясень", "Размер": "40×30×25 см", "Ящики": "1 шт.", "Монтаж": "Навесной" } },
    { id: 8, name: "Тумба Oval Marble Top", cat: "nightstands", catName: "Тумбы", price: 18200, tag: "Премиум", img: "https://images.unsplash.com/photo-1707980716909-61b696e2b84d?fm=jpg&q=60&w=3000&auto=format&fit=crop", desc: "Тумба с овальной столешницей из мрамора.", specs: { "Материал": "Мрамор", "Размер": "50×40×55 см", "Столешница": "Мрамор", "Гарантия": "5 лет" } },
    { id: 9, name: "Тумба Brass Details Luxury", cat: "nightstands", catName: "Тумбы", price: 16500, tag: "Хит", img: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=600&q=80", desc: "Тумба с латунными ручками.", specs: { "Материал": "Берёза", "Размер": "48×38×58 см", "Фурнитура": "Латунь", "Гарантия": "5 лет" } },
    { id: 10, name: "Тумба Minimal Dark Walnut", cat: "nightstands", catName: "Тумбы", price: 13900, tag: "SALE", img: "https://images.unsplash.com/photo-1765766602624-861292c3bc8f?fm=jpg&q=60&w=3000&auto=format&fit=crop", desc: "Минималистичная тумба.", specs: { "Материал": "Орех", "Размер": "45×40×50 см", "Открывание": "Push-to-open", "Гарантия": "3 года" } },
    { id: 11, name: "Матрас Serenity Ortho Premium", cat: "mattresses", catName: "Матрасы", price: 36000, tag: "Хит продаж", img: "https://media.istockphoto.com/id/1168119009/photo/bedroom-interior-double-bed-retro-style-hotel-bedroom.webp?a=1&b=1&s=612x612&w=0&k=20&c=qzeT4ou_0D_Ogz3CQCN8ff0pd3BbSfTsIddP_5xfbrE=", desc: "Ортопедический матрас средней жёсткости.", specs: { "Жёсткость": "Средняя", "Наполнение": "Пружины", "Высота": "22 см", "Чехол": "Жаккард" } },
    { id: 12, name: "Матрас Memory Foam Relax Cloud", cat: "mattresses", catName: "Матрасы", price: 45000, tag: "Новинка", img: "https://media.istockphoto.com/id/2283255096/photo/orthopedic-mattress-and-pillows-on-bed-indoors.webp?a=1&b=1&s=612x612&w=0&k=20&c=FRS0E7IbGZlIAVFxwIBtskIO_frFLeG8Kgj9tkc7AiI=", desc: "Матрас с эффектом памяти.", specs: { "Жёсткость": "Средне-мягкая", "Наполнение": "Memory", "Высота": "25 см", "Чехол": "Алоэ вера" } },
    { id: 13, name: "Матрас Natural Latex Deluxe", cat: "mattresses", catName: "Матрасы", price: 58000, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=fdcca5ab89849c2e73c06d1efe7e63599d14eafe-4458806-images-thumbs&n=13", desc: "Матрас на натуральном латексе.", specs: { "Жёсткость": "Средняя", "Наполнение": "Латекс", "Высота": "24 см", "Гарантия": "10 лет" } },
    { id: 14, name: "Матрас Pocket Spring Balance", cat: "mattresses", catName: "Матрасы", price: 29500, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=9653b93a60bc8843b343123b57562e1b9630871c-7743892-images-thumbs&n=13", desc: "Матрас на независимых пружинах.", specs: { "Жёсткость": "Средняя", "Пружины": "Pocket", "Высота": "20 см", "Чехол": "Трикотаж" } },
    { id: 15, name: "Матрас Royal Hybrid Anatomical", cat: "mattresses", catName: "Матрасы", price: 64000, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=3971c440ac8828982f94a67d6293a74e2d233316-10266303-images-thumbs&n=13", desc: "Гибридный матрас с 7 зонами.", specs: { "Жёсткость": "Средне-жёсткая", "Зоны": "7", "Высота": "27 см", "Гарантия": "10 лет" } },
    { id: 16, name: "Шкаф Двухстворчатый Nordik Ash", cat: "wardrobes", catName: "Шкафы", price: 74000, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=723f93cf64455dbb2f04d38ec2cb94629db4d9de-9846809-images-thumbs&n=13", desc: "Шкаф из массива ясеня.", specs: { "Материал": "Ясень", "Размер": "120×60×220 см", "Полки": "4", "Гарантия": "5 лет" } },
    { id: 17, name: "Шкаф Трёхстворчатый с Зеркалом", cat: "wardrobes", catName: "Шкафы", price: 98000, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=a59640e1468a5add4f6f64c6de9c750e36c6138d-5655335-images-thumbs&n=13", desc: "Шкаф с зеркалом.", specs: { "Материал": "ЛДСП", "Размер": "180×60×230 см", "Зеркало": "Да", "Гарантия": "5 лет" } },
    { id: 18, name: "Шкаф Glass Sliding Doors", cat: "wardrobes", catName: "Шкафы", price: 82000, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=716aa3bcb79ac56d290ce3cc6bdfce24c3d8e8e0-5583274-images-thumbs&n=13", desc: "Шкаф-купе со стеклом.", specs: { "Материал": "Алюминий", "Размер": "200×60×230 см", "Двери": "2", "Профиль": "Чёрный" } },
    { id: 19, name: "Шкаф Угловой SpaceMax", cat: "wardrobes", catName: "Шкафы", price: 69000, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=00814b1f45d5564ba33ff65ec1e8cda4cac7f089-4565676-images-thumbs&n=13", desc: "Угловой шкаф.", specs: { "Материал": "ЛДСП", "Размер": "200×90×220 см", "Полки": "6", "Гарантия": "3 года" } },
    { id: 20, name: "Шкаф Встроенный Modular Wood", cat: "wardrobes", catName: "Шкафы", price: 110000, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=dad0457077e3bc23d579ccd73b96c14371b43375-16509553-images-thumbs&n=13", desc: "Встроенный шкаф.", specs: { "Материал": "Массив", "Размер": "Индивид.", "Высота": "Под потолок", "Монтаж": "Встроенный" } },
    { id: 21, name: "Комод Velvet Touch 4 Ящика", cat: "dressers", catName: "Комоды", price: 32000, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=dac9a69ec82c5e947b0bd9d4033e563341bbc962-5887733-images-thumbs&n=13", desc: "Комод с 4 ящиками.", specs: { "Материал": "Берёза", "Размер": "100×50×85 см", "Ящики": "4", "Гарантия": "5 лет" } },
    { id: 22, name: "Комод Высокий Slim 6 Ящиков", cat: "dressers", catName: "Комоды", price: 38000, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=2dcd853d881beb92d659d6091eeed9b3871b8a6b-12322137-images-thumbs&n=13", desc: "Высокий комод.", specs: { "Материал": "Ясень", "Размер": "60×45×120 см", "Ящики": "6", "Гарантия": "5 лет" } },
    { id: 23, name: "Комод Wide Solid Ash", cat: "dressers", catName: "Комоды", price: 46000, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=e8935a6d6f48ca2ed42ba25b79d5d43e92ac97e5-5875509-images-thumbs&n=13", desc: "Широкий комод.", specs: { "Материал": "Ясень", "Размер": "140×50×90 см", "Ящики": "5", "Гарантия": "7 лет" } },
    { id: 24, name: "Комод Retro Walnut Mid-Century", cat: "dressers", catName: "Комоды", price: 35000, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=334a1be3ed757f5734853757d9cb7e46d6885a6c-12641163-images-thumbs&n=13", desc: "Комод mid-century.", specs: { "Материал": "Орех", "Размер": "120×45×80 см", "Стиль": "Mid-century", "Гарантия": "5 лет" } },
    { id: 25, name: "Комод Minimal Off-White", cat: "dressers", catName: "Комоды", price: 29000, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=33515122fce95e24036464be77d4e90ff8bfd3c9-8485406-images-thumbs&n=13", desc: "Светлый комод.", specs: { "Материал": "МДФ", "Размер": "110×45×80 см", "Ящики": "4", "Гарантия": "3 года" } },
    { id: 26, name: "Столик Grace с круглым зеркалом", cat: "vanity", catName: "Столики", price: 28500, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=0d0d8348b4e4e8556998ffc5723cedfede1b28b8-4370398-images-thumbs&n=13", desc: "Столик с зеркалом.", specs: { "Материал": "Массив", "Размер": "100×45×75 см", "Зеркало": "D=60", "Гарантия": "5 лет" } },
    { id: 27, name: "Столик LED Studio Light", cat: "vanity", catName: "Столики", price: 36000, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=cddcc2add5f96058458090696287103dc173966c-5450792-images-thumbs&n=13", desc: "Столик с LED.", specs: { "Материал": "МДФ", "Размер": "110×45×78 см", "Подсветка": "LED", "Гарантия": "3 года" } },
    { id: 28, name: "Столик Compact Marble Leg", cat: "vanity", catName: "Столики", price: 23000, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=37852384872e8e2255202bbe653a2c582e7cdf63-3530254-images-thumbs&n=13", desc: "Столик на мраморных ножках.", specs: { "Материал": "Мрамор", "Размер": "80×40×75 см", "Ножки": "Мрамор", "Гарантия": "3 года" } },
    { id: 29, name: "Столик Minimal Wood Console", cat: "vanity", catName: "Столики", price: 25000, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=5776c65cf4477941f96b4f3ac519b93fa4424ef4-5582903-images-thumbs&n=13", desc: "Консоль.", specs: { "Материал": "Дуб", "Размер": "110×35×75 см", "Покрытие": "Воск", "Гарантия": "5 лет" } },
    { id: 30, name: "Столик Golden Accents Luxury", cat: "vanity", catName: "Столики", price: 42000, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=d075387b4fd2fcdd0e073e63566b548ddfe55c82-4364981-images-thumbs&n=13", desc: "Столик с золотом.", specs: { "Материал": "МДФ", "Размер": "120×50×78 см", "Фурнитура": "Латунь", "Гарантия": "5 лет" } },
    { id: 31, name: "Зеркало Напольное Reflex Full", cat: "mirrors", catName: "Зеркала", price: 18500, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=b24b066ba6f5e46ef21117c20485fb94328d1757-7012718-images-thumbs&n=13", desc: "Напольное зеркало.", specs: { "Материал": "Ясень", "Размер": "60×170 см", "Рама": "Дерево", "Крепление": "Напольное" } },
    { id: 32, name: "Зеркало Арочное Arch Brass", cat: "mirrors", catName: "Зеркала", price: 24000, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=595de2924dd798a269ac4a88e8cb39422c16920d-5242334-images-thumbs&n=13", desc: "Арочное зеркало.", specs: { "Материал": "Латунь", "Размер": "70×180 см", "Форма": "Арочная", "Гарантия": "3 года" } },
    { id: 33, name: "Зеркало Настенное Sunburst", cat: "mirrors", catName: "Зеркала", price: 14500, tag: "Премиум", img: "https://images.unsplash.com/photo-1615529182904-14819c35db37?auto=format&fit=crop&w=600&q=80", desc: "Зеркало-солнце.", specs: { "Материал": "Металл", "Размер": "D=80 см", "Стиль": "Sunburst", "Гарантия": "2 года" } },
    { id: 34, name: "Зеркало Perimeter LED Light", cat: "mirrors", catName: "Зеркала", price: 29000, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=d9e9416aad7d44ea355cb914861a112719069f09-5572268-images-thumbs&n=13", desc: "Зеркало с LED.", specs: { "Материал": "Стекло", "Размер": "80×160 см", "Подсветка": "LED", "Гарантия": "3 года" } },
    { id: 35, name: "Зеркало Loft Wood Frame", cat: "mirrors", catName: "Зеркала", price: 16800, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=4973d43825e537c6dd064d5dc596dce6842d7384-7133642-images-thumbs&n=13", desc: "Зеркало в раме.", specs: { "Материал": "Сосна", "Размер": "70×150 см", "Рама": "Дерево", "Гарантия": "2 года" } },
    { id: 36, name: "Лампа прикроватная WarmGlow", cat: "lamps", catName: "Лампы", price: 8900, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=ab734af8ff9c909e5d47e0e5b30c24d53e86865a-4809761-images-thumbs&n=13", desc: "Тёплая лампа.", specs: { "Материал": "Керамика", "Высота": "45 см", "Цоколь": "E27", "Мощность": "60 Вт" } },
    { id: 37, name: "Лампа Керамическая Soft Base", cat: "lamps", catName: "Лампы", price: 11200, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=20fe005ff362a6da16a2d871b4da5053dcdc32df-5333586-images-thumbs&n=13", desc: "Лампа ручной работы.", specs: { "Материал": "Керамика", "Высота": "50 см", "Цоколь": "E27", "Ручная": "Да" } },
    { id: 38, name: "Лампа Touch Dimmable Modern", cat: "lamps", catName: "Лампы", price: 13500, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=5aafd4e358345fee0c201ef2d23a0a379a831349-5588836-images-thumbs&n=13", desc: "Сенсорная лампа.", specs: { "Материал": "Металл", "Высота": "42 см", "Управление": "Сенсор", "Цоколь": "LED" } },
    { id: 39, name: "Лампа Marble Sphere Light", cat: "lamps", catName: "Лампы", price: 15400, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=a7edba00d3446f4de05646d79269b4cfcd8bb2ba-5302151-images-thumbs&n=13", desc: "Мраморная лампа.", specs: { "Материал": "Мрамор", "Высота": "48 см", "Основание": "Мрамор", "Цоколь": "E27" } },
    { id: 40, name: "Лампа Minimal Matte Black", cat: "lamps", catName: "Лампы", price: 7900, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=6572db822fe40001d24b1cddcbb23967621a0707-5561596-images-thumbs&n=13", desc: "Чёрная лампа.", specs: { "Материал": "Металл", "Высота": "40 см", "Цвет": "Чёрный", "Цоколь": "E27" } },
    { id: 41, name: "Банкетка Прикроватная Cozo", cat: "benches", catName: "Банкетки", price: 13200, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=2ab8a7bac44e3a98bbb752725a8d5cf8d12ed948-5578090-images-thumbs&n=13", desc: "Банкетка у кровати.", specs: { "Материал": "Ткань", "Размер": "90×40×45 см", "Обивка": "Рогожка", "Гарантия": "3 года" } },
    { id: 42, name: "Банкетка Boucle Soft Cushion", cat: "benches", catName: "Банкетки", price: 17800, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=cb9992a5620080309ca69c1826faa035d16be1a3-4698038-images-thumbs&n=13", desc: "Банкетка букле.", specs: { "Материал": "Букле", "Размер": "100×45×45 см", "Обивка": "Букле", "Гарантия": "3 года" } },
    { id: 43, name: "Пуф Круглый Velvet Pouf", cat: "benches", catName: "Банкетки", price: 8900, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=fd49baf5d69c7b683fd4ccee76fc1dfb1b0404bb-2938391-images-thumbs&n=13", desc: "Велюровый пуф.", specs: { "Материал": "Велюр", "Диаметр": "45 см", "Высота": "40 см", "Наполнитель": "ППУ" } },
    { id: 44, name: "Банкетка Storage Bench", cat: "benches", catName: "Банкетки", price: 21000, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=1e0cc5c98369d376a0e5079eb244053ef5e2637c-5232579-images-thumbs&n=13", desc: "С ящиком.", specs: { "Материал": "Ткань", "Размер": "110×45×45 см", "Хранение": "Да", "Гарантия": "3 года" } },
    { id: 45, name: "Банкетка Leather Brass Base", cat: "benches", catName: "Банкетки", price: 24500, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=7bfff0dbcd3e3f51e5f9830a4e5e7c7dbc2905e8-9215166-images-thumbs&n=13", desc: "Кожаная.", specs: { "Материал": "Кожа", "Размер": "100×40×45 см", "Обивка": "Кожа", "Гарантия": "5 лет" } },
    { id: 46, name: "Кресло Lounge Soft Velvet", cat: "armchairs", catName: "Кресла", price: 26900, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=1c4f1b41ba1985a5536c9e4ec328db8766d3e9ca-5341701-images-thumbs&n=13", desc: "Кресло-лаунж.", specs: { "Материал": "Велюр", "Размер": "75×80×85 см", "Обивка": "Велюр", "Гарантия": "3 года" } },
    { id: 47, name: "Кресло Emerald Accent Chair", cat: "armchairs", catName: "Кресла", price: 32500, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=0046a669a45bf069c1d3bff5a3e2be7657578d9e-9181306-images-thumbs&n=13", desc: "Изумрудное кресло.", specs: { "Материал": "Ткань", "Размер": "70×75×80 см", "Цвет": "Изумруд", "Гарантия": "3 года" } },
    { id: 48, name: "Кресло-качалка Modern Rocker", cat: "armchairs", catName: "Кресла", price: 37000, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=f9fc2962acd06f55dbdaa13aaa9f3e58bf1b21be-10414649-images-thumbs&n=13", desc: "Качалка.", specs: { "Материал": "Бук", "Размер": "70×90×95 см", "Механизм": "Качалка", "Гарантия": "5 лет" } },
    { id: 49, name: "Кресло Cozy Boucle Fabric", cat: "armchairs", catName: "Кресла", price: 34800, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=41cf60f59d73b9ac11f70409a7881facba5dc662-11547032-images-thumbs&n=13", desc: "Уютное кресло.", specs: { "Материал": "Букле", "Размер": "80×85×90 см", "Обивка": "Букле", "Гарантия": "3 года" } },
    { id: 50, name: "Кресло Minimalist Wood Legs", cat: "armchairs", catName: "Кресла", price: 28400, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=4a86cdcdbdb1a589e0df70d1de2f4abb177dd76b-4984230-images-thumbs&n=13", desc: "На деревянных ножках.", specs: { "Материал": "Ткань", "Размер": "70×75×80 см", "Ножки": "Дуб", "Гарантия": "3 года" } },
    { id: 51, name: "Бра Настенное Minimal Brass", cat: "sconces", catName: "Бра", price: 6400, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=89e2b23f83085f9747f1134d2a093d61b83354e3-4507655-images-thumbs&n=13", desc: "Латунное бра.", specs: { "Материал": "Латунь", "Высота": "25 см", "Цоколь": "E14", "Монтаж": "Настенный" } },
    { id: 52, name: "Бра Поворотное Reading Lamp", cat: "sconces", catName: "Бра", price: 7800, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=79dcfa21f3d5e5d021740128ed0205f7bcee83c1-6454405-images-thumbs&n=13", desc: "Поворотное бра.", specs: { "Материал": "Металл", "Высота": "20 см", "Поворот": "180°", "Цоколь": "E14" } },
    { id: 53, name: "Бра Sphere Glass Shade", cat: "sconces", catName: "Бра", price: 8900, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=638febc4170e983941ab7d6c14a88b5189606eea-12377022-images-thumbs&n=13", desc: "Стеклянное бра.", specs: { "Материал": "Стекло", "Диаметр": "15 см", "Плафон": "Стекло", "Цоколь": "E14" } },
    { id: 54, name: "Бра Двойное Twin Brass Light", cat: "sconces", catName: "Бра", price: 10200, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=8945356082a9d8df7f1bb3245d4c047193924065-5866271-images-thumbs&n=13", desc: "Двойное бра.", specs: { "Материал": "Латунь", "Высота": "30 см", "Плафоны": "2", "Цоколь": "E14" } },
    { id: 55, name: "Бра Halo LED Ambient Light", cat: "sconces", catName: "Бра", price: 9400, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=ab3655cfbb83deb992bdba75b7f13b7a11277041-10268218-images-thumbs&n=13", desc: "LED-бра.", specs: { "Материал": "Металл", "Диаметр": "30 см", "Источник": "LED", "Цвет": "Тёплый" } },
    { id: 56, name: "Ковер Напольный Cozy Wool", cat: "rugs", catName: "Ковры", price: 16300, tag: "Хит продаж", img: "https://avatars.mds.yandex.net/i?id=d443b5b479fabbfae8ad415fb986da1ac077cf29-3920892-images-thumbs&n=13", desc: "Шерстяной ковер.", specs: { "Материал": "Шерсть", "Размер": "160×230 см", "Ворс": "Короткий", "Страна": "Россия" } },
    { id: 57, name: "Ковер Boho Pattern Neutral", cat: "rugs", catName: "Ковры", price: 21500, tag: "Новинка", img: "https://avatars.mds.yandex.net/i?id=aceb610c7de753e4a62ddf84a7cb83fa29a5ca46-9618143-images-thumbs&n=13", desc: "Бохо ковер.", specs: { "Материал": "Полипропилен", "Размер": "200×290 см", "Ворс": "Средний", "Уход": "Химчистка" } },
    { id: 58, name: "Ковер Высокий Ворс Soft Cloud", cat: "rugs", catName: "Ковры", price: 24000, tag: "Премиум", img: "https://avatars.mds.yandex.net/i?id=417f32e0393c9fec56b89a0eef30671ed7824458-4055867-images-thumbs&n=13", desc: "Пушистый ковер.", specs: { "Материал": "Микрополиэстер", "Размер": "180×250 см", "Ворс": "Длинный", "Цвет": "Бежевый" } },
    { id: 59, name: "Плед Кашемировый Warm Gray", cat: "rugs", catName: "Ковры", price: 11800, tag: "Хит", img: "https://avatars.mds.yandex.net/i?id=ac5d03140c4dd53c7e303ee976c95870880484e7-5278533-images-thumbs&n=13", desc: "Мягкий плед.", specs: { "Материал": "Кашемир", "Размер": "140×200 см", "Цвет": "Серый", "Уход": "Ручная" } },
    { id: 60, name: "Подушки Декоративные Silk (2 шт)", cat: "rugs", catName: "Ковры", price: 6800, tag: "SALE", img: "https://avatars.mds.yandex.net/i?id=eada1a7f7963f9e7086719e44b8a3c3c80098f3d-8257715-images-thumbs&n=13", desc: "Шелковые подушки.", specs: { "Материал": "Шёлк", "Размер": "45×45 см", "Комплект": "2", "Наполнитель": "Синтепух" } }
];

let cart = [];
let activeCategory = 'all';
let searchQuery = '';
let minPrice = null;
let maxPrice = null;
let sortBy = 'default';
let currentProductId = null;

/* ============================================================
 *  КАРТОЧКИ ТОВАРОВ
 * ============================================================ */
const catalogGrid = document.getElementById('catalogGrid');
const newArrivalsGrid = document.getElementById('newArrivalsGrid');
const searchInput = document.getElementById('searchInput');
const minPriceInput = document.getElementById('minPrice');
const maxPriceInput = document.getElementById('maxPrice');
const sortSelect = document.getElementById('sortSelect');
const categoryChips = document.getElementById('categoryChips');
const resetFiltersBtn = document.getElementById('resetFiltersBtn');
const resultsCountEl = document.getElementById('resultsCount');

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <div class="product-tag">${product.tag}</div>
        <div class="img-wrapper"><img src="${product.img}" alt="${product.name}" class="product-img" loading="lazy"></div>
        <div class="product-info">
            <span class="product-category">${product.catName}</span>
            <h3 class="product-title">${product.name}</h3>
            <div class="product-footer">
                <span class="product-price">${product.price.toLocaleString('ru-RU')} ₽</span>
                <button class="add-btn" data-action="add">В корзину</button>
            </div>
        </div>
    `;
    card.addEventListener('click', (e) => {
        if (e.target.closest('[data-action="add"]')) return;
        openProductModal(product.id);
    });
    card.querySelector('[data-action="add"]').addEventListener('click', (e) => {
        e.stopPropagation();
        addToCart(product.id, e.currentTarget);
    });
    return card;
}

function renderCatalog() {
    let filtered = products.filter(item => {
        const matchCat = activeCategory === 'all' || item.cat === activeCategory;
        const matchSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || item.catName.toLowerCase().includes(searchQuery.toLowerCase());
        const matchMinPrice = minPrice === null || item.price >= minPrice;
        const matchMaxPrice = maxPrice === null || item.price <= maxPrice;
        return matchCat && matchSearch && matchMinPrice && matchMaxPrice;
    });

    if (sortBy === 'asc') filtered.sort((a, b) => a.price - b.price);
    if (sortBy === 'desc') filtered.sort((a, b) => b.price - a.price);

    resultsCountEl.textContent = `Найдено позиций: ${filtered.length}`;
    catalogGrid.innerHTML = '';
    if (filtered.length === 0) {
        catalogGrid.innerHTML = '<div class="empty-state">По Вашему запросу ничего не найдено</div>';
        return;
    }
    filtered.forEach(product => catalogGrid.appendChild(createProductCard(product)));
}

function renderNewArrivals() {
    const fresh = products.filter(p => p.tag === "Новинка").slice(0, 8);
    newArrivalsGrid.innerHTML = '';
    if (fresh.length === 0) return;
    fresh.forEach(product => newArrivalsGrid.appendChild(createProductCard(product)));
}

/* ============================================================
 *  МОДАЛКА ТОВАРА
 * ============================================================ */
const productModal = document.getElementById('productModal');
const pmImage = document.getElementById('pmImage');
const pmCategory = document.getElementById('pmCategory');
const pmTitle = document.getElementById('pmTitle');
const pmPrice = document.getElementById('pmPrice');
const pmDesc = document.getElementById('pmDesc');
const pmSpecs = document.getElementById('pmSpecs');
const pmAddBtn = document.getElementById('pmAddBtn');
const pmClose = document.getElementById('pmClose');
const pmCloseBtn = document.getElementById('pmCloseBtn');

function openProductModal(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;
    currentProductId = id;
    pmImage.style.backgroundImage = `url('${product.img}')`;
    pmCategory.textContent = product.catName;
    pmTitle.textContent = product.name;
    pmPrice.textContent = product.price.toLocaleString('ru-RU') + ' ₽';
    pmDesc.textContent = product.desc || '';
    pmSpecs.innerHTML = '';
    if (product.specs) {
        Object.entries(product.specs).forEach(([key, value]) => {
            const li = document.createElement('li');
            li.innerHTML = `<span>${key}</span><span>${value}</span>`;
            pmSpecs.appendChild(li);
        });
    }
    pmAddBtn.textContent = 'В корзину';
    pmAddBtn.classList.remove('added');
    productModal.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeProductModal() {
    productModal.classList.remove('open');
    document.body.style.overflow = '';
    currentProductId = null;
}

pmClose.addEventListener('click', closeProductModal);
pmCloseBtn.addEventListener('click', closeProductModal);
productModal.addEventListener('click', (e) => { if (e.target === productModal) closeProductModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && productModal.classList.contains('open')) closeProductModal(); });
pmAddBtn.addEventListener('click', () => { if (currentProductId !== null) addToCart(currentProductId, pmAddBtn); });

/* ============================================================
 *  КОРЗИНА
 * ============================================================ */
const cartOverlay = document.getElementById('cartOverlay');
const openCartBtn = document.getElementById('openCart');
const closeCartBtn = document.getElementById('closeCart');
const cartItemsContainer = document.getElementById('cartItems');
const cartCountBadge = document.getElementById('cartCount');
const totalPriceEl = document.getElementById('totalPrice');

function addToCart(id, btn) {
    const product = products.find(p => p.id === id);
    if (!product) return;
    const existing = cart.find(item => item.id === id);
    if (existing) { existing.qty++; } else { cart.push({ ...product, qty: 1 }); }

    if (btn) {
        const original = btn.textContent;
        btn.textContent = 'Добавлено!';
        btn.classList.add('added');
        setTimeout(() => {
            btn.textContent = original === 'Добавлено!' ? 'В корзину' : original;
            btn.classList.remove('added');
        }, 1200);
    }
    updateCart();
}

function updateCart() {
    const totalCount = cart.reduce((sum, item) => sum + item.qty, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    cartCountBadge.textContent = totalCount;
    totalPriceEl.textContent = totalPrice.toLocaleString('ru-RU') + ' ₽';
    cartItemsContainer.innerHTML = '';
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p style="color: var(--text-muted); text-align: center; margin-top: 40px;">Корзина пуста</p>';
        return;
    }
    cart.forEach(item => {
        const el = document.createElement('div');
        el.className = 'cart-item';
        el.innerHTML = `
            <img src="${item.img}" class="cart-item-img">
            <div class="cart-item-details">
                <div class="cart-item-title">${item.name}</div>
                <div class="cart-item-price">${(item.price * item.qty).toLocaleString('ru-RU')} ₽</div>
                <div class="qty-controls">
                    <button class="qty-btn" onclick="changeQty(${item.id}, -1)">-</button>
                    <span>${item.qty}</span>
                    <button class="qty-btn" onclick="changeQty(${item.id}, 1)">+</button>
                </div>
            </div>
        `;
        cartItemsContainer.appendChild(el);
    });
}

function changeQty(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) { cart = cart.filter(i => i.id !== id); }
    updateCart();
}

openCartBtn.addEventListener('click', () => cartOverlay.classList.add('open'));
closeCartBtn.addEventListener('click', () => cartOverlay.classList.remove('open'));
cartOverlay.addEventListener('click', e => { if (e.target === cartOverlay) cartOverlay.classList.remove('open'); });

/* ============================================================
 *  АВТОРИЗАЦИЯ (С ОТОБРАЖЕНИЕМ ИМЕНИ)
 * ============================================================ */
const authOverlay = document.getElementById('authOverlay');
const openAuthBtn = document.getElementById('openAuth');
const closeAuthBtn = document.getElementById('closeAuth');
const authIcon = document.getElementById('authIcon');
const authUserName = document.getElementById('authUserName');
let isLoginMode = true;

// Проверяем, не заходил ли пользователь ранее (сохраняем в localStorage)
if (localStorage.getItem('sleepcraft_username') && authUserName && authIcon) {
    const savedName = localStorage.getItem('sleepcraft_username');
    authUserName.textContent = savedName;
    authUserName.style.display = 'inline';
    authIcon.style.display = 'none';
    openAuthBtn.style.padding = '0 16px';
}

openAuthBtn.addEventListener('click', () => {
    if (authUserName && authUserName.style.display !== 'none' && authUserName.textContent !== '') {
        if (confirm('Вы действительно хотите выйти из аккаунта?')) {
            authUserName.textContent = '';
            authUserName.style.display = 'none';
            authIcon.style.display = 'block';
            openAuthBtn.style.padding = '';
            localStorage.removeItem('sleepcraft_username');
        }
    } else {
        authOverlay.classList.add('open');
    }
});

closeAuthBtn.addEventListener('click', () => authOverlay.classList.remove('open'));
authOverlay.addEventListener('click', e => { if (e.target === authOverlay) authOverlay.classList.remove('open'); });

document.getElementById('tabLogin').addEventListener('click', function() {
    this.classList.add('active');
    document.getElementById('tabRegister').classList.remove('active');
    isLoginMode = true;
    document.getElementById('usernameGroup').classList.add('hidden');
});
document.getElementById('tabRegister').addEventListener('click', function() {
    this.classList.add('active');
    document.getElementById('tabLogin').classList.remove('active');
    isLoginMode = false;
    document.getElementById('usernameGroup').classList.remove('hidden');
});

document.getElementById('authForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const statusEl = document.getElementById('authStatus');
    statusEl.className = 'ff-status';

    const email = document.getElementById('authEmail').value.trim();
    const password = document.getElementById('authPassword').value;
    const usernameInput = document.getElementById('authUsername');
    const username = usernameInput ? usernameInput.value.trim() : '';

    const url = isLoginMode ? 'http://localhost:8081/api/login' : 'http://localhost:8081/api/register';
    const body = isLoginMode ? { email, password } : { email, password, username };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await response.json();

        if (response.ok) {
            if (data.username && authUserName && authIcon) {
                authUserName.textContent = data.username;
                authUserName.style.display = 'inline';
                authIcon.style.display = 'none';
                openAuthBtn.style.padding = '0 16px';
                localStorage.setItem('sleepcraft_username', data.username);
            }

            statusEl.textContent = data.message;
            statusEl.className = 'ff-status ok';
            setTimeout(() => {
                authOverlay.classList.remove('open');
                statusEl.className = 'ff-status';
                document.getElementById('authForm').reset();
            }, 2000);
        } else {
            statusEl.textContent = data.message || 'Ошибка';
            statusEl.className = 'ff-status err';
        }
    } catch (err) {
        statusEl.textContent = 'Ошибка соединения с сервером';
        statusEl.className = 'ff-status err';
    }
});

/* ============================================================
 *  ОФОРМЛЕНИЕ ЗАКАЗА
 * ============================================================ */
document.getElementById('checkoutBtn').addEventListener('click', async () => {
    const statusEl = document.getElementById('orderStatus');
    statusEl.className = 'ff-status';

    if (cart.length === 0) {
        statusEl.textContent = 'Корзина пуста';
        statusEl.className = 'ff-status err';
        return;
    }

    const name = document.getElementById('orderName').value.trim();
    const phone = document.getElementById('orderPhone').value.trim();
    const address = document.getElementById('orderAddress').value.trim();

    if (!name || !phone || !address) {
        statusEl.textContent = 'Заполните все поля!';
        statusEl.className = 'ff-status err';
        return;
    }

    if (!/^8\d{10}$/.test(phone)) {
        statusEl.textContent = 'Телефон должен быть в формате 89674516420';
        statusEl.className = 'ff-status err';
        return;
    }

    statusEl.textContent = 'Отправка заказа...';
    statusEl.className = 'ff-status';

    const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const orderData = { name, phone, address, items: cart, total };

    try {
        const response = await fetch('http://localhost:8081/api/orders', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });

        if (response.ok) {
            statusEl.textContent = 'Заказ оформлен! Мы свяжемся с вами.';
            statusEl.className = 'ff-status ok';
            cart = [];
            updateCart();
            setTimeout(() => {
                document.getElementById('cartOverlay').classList.remove('open');
                statusEl.className = 'ff-status';
            }, 3000);
        } else {
            throw new Error('Ошибка сервера');
        }
    } catch (err) {
        statusEl.textContent = 'Ошибка отправки. Проверьте, запущен ли сервер.';
        statusEl.className = 'ff-status err';
    }
});

/* ============================================================
 *  МОДАЛКИ (Форма связи и Политика)
 * ============================================================ */
const feedbackModal = document.getElementById('feedbackModal');
const openFeedback = document.getElementById('openFeedback');
const openFeedback2 = document.getElementById('openFeedback2');
const closeFeedback = document.getElementById('closeFeedback');

function showFeedbackModal() { feedbackModal.classList.add('open'); document.body.style.overflow = 'hidden'; }
function hideFeedbackModal() { feedbackModal.classList.remove('open'); document.body.style.overflow = ''; }

openFeedback.addEventListener('click', showFeedbackModal);
openFeedback2.addEventListener('click', showFeedbackModal);
closeFeedback.addEventListener('click', hideFeedbackModal);
feedbackModal.addEventListener('click', e => { if (e.target === feedbackModal) hideFeedbackModal(); });

const feedbackForm = document.getElementById('feedbackForm');
const fbStatus = document.getElementById('fbStatus');

feedbackForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('fbName').value.trim();
    const phone = document.getElementById('fbPhone').value.trim();
    const consent = document.getElementById('fbConsent').checked;

    if (!name || !phone || !consent) {
        fbStatus.textContent = 'Заполните все поля и дайте согласие.';
        fbStatus.className = 'ff-status err';
        return;
    }
    fbStatus.textContent = 'Отправка...';
    fbStatus.className = 'ff-status';

    fetch(feedbackForm.action, { method: 'POST', body: new FormData(feedbackForm), headers: { 'Accept': 'application/json' } })
    .then(response => {
        if (response.ok) {
            fbStatus.textContent = `Спасибо, ${name}! Мы свяжемся с вами.`;
            fbStatus.className = 'ff-status ok';
            feedbackForm.reset();
            setTimeout(() => { hideFeedbackModal(); fbStatus.className = 'ff-status'; fbStatus.textContent = ''; }, 3000);
        } else { throw new Error(); }
    })
    .catch(() => {
        fbStatus.textContent = 'Не удалось отправить. Попробуйте позвонить.';
        fbStatus.className = 'ff-status err';
    });
});

const privacyModal = document.getElementById('privacyModal');
const closePrivacy = document.getElementById('closePrivacy');
const openPrivacy1 = document.getElementById('openPrivacy1');
const openPrivacy2 = document.getElementById('openPrivacy2');

function showPrivacyModal(e) { if(e) e.preventDefault(); privacyModal.classList.add('open'); }
function hidePrivacyModal() { privacyModal.classList.remove('open'); }

openPrivacy1.addEventListener('click', showPrivacyModal);
openPrivacy2.addEventListener('click', showPrivacyModal);
closePrivacy.addEventListener('click', hidePrivacyModal);
privacyModal.addEventListener('click', e => { if (e.target === privacyModal) hidePrivacyModal(); });

/* ============================================================
 *  ФИЛЬТРЫ И СОРТИРОВКА
 * ============================================================ */
searchInput.addEventListener('input', e => { searchQuery = e.target.value; renderCatalog(); });
minPriceInput.addEventListener('input', e => { minPrice = e.target.value ? Number(e.target.value) : null; renderCatalog(); });
maxPriceInput.addEventListener('input', e => { maxPrice = e.target.value ? Number(e.target.value) : null; renderCatalog(); });
sortSelect.addEventListener('change', e => { sortBy = e.target.value; renderCatalog(); });

categoryChips.addEventListener('click', e => {
    if (e.target.classList.contains('chip')) {
        document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        activeCategory = e.target.dataset.cat;
        renderCatalog();
    }
});

resetFiltersBtn.addEventListener('click', () => {
    minPriceInput.value = '';
    maxPriceInput.value = '';
    minPrice = null; maxPrice = null;
    sortSelect.value = 'default'; sortBy = 'default';
    searchInput.value = ''; searchQuery = '';
    renderCatalog();
});

/* ============================================================
 *  COOKIE
 * ============================================================ */
const cookieBanner = document.getElementById('cookieBanner');
const cookieAccept = document.getElementById('cookieAccept');
const cookieDecline = document.getElementById('cookieDecline');
const COOKIE_KEY = 'sleepcraft_cookie_consent';

if (!localStorage.getItem(COOKIE_KEY)) {
    setTimeout(() => cookieBanner.classList.add('show'), 800);
}
function hideCookieBanner(choice) {
    localStorage.setItem(COOKIE_KEY, choice);
    cookieBanner.classList.remove('show');
}
cookieAccept.addEventListener('click', () => hideCookieBanner('accepted'));
cookieDecline.addEventListener('click', () => hideCookieBanner('declined'));

/* ============================================================
 *  СТАРТ
 * ============================================================ */
renderCatalog();
renderNewArrivals();
updateCart();