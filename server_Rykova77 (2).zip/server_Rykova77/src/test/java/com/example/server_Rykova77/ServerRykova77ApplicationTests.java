package com.example.server_Rykova77;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRykova77ApplicationTests {

	@Test
	void contextLoads() {
	}

}
