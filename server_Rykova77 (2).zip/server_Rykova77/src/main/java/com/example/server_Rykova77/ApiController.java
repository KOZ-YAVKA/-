package com.example.server_Rykova77;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Чтобы JS с сайта мог присылать данные
public class ApiController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    // === РЕГИСТРАЦИЯ ===
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if (user.getEmail() == null || !user.getEmail().contains("@")) {
            return ResponseEntity.badRequest().body(Map.of("message", "Некорректная почта"));
        }
        if (user.getPassword() == null || user.getPassword().length() < 6) {
            return ResponseEntity.badRequest().body(Map.of("message", "Пароль должен быть больше 6 символов"));
        }
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Такая почта уже зарегистрирована"));
        }

        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            user.setUsername("Пользователь");
        }

        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "Регистрация успешна!", "username", user.getUsername()));
    }

    // === ВХОД ===
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String password = request.get("password");

        User user = userRepository.findByEmail(email).orElse(null);
        if (user == null || !user.getPassword().equals(password)) {
            return ResponseEntity.badRequest().body(Map.of("message", "Неверная почта или пароль"));
        }

        return ResponseEntity.ok(Map.of("message", "Вход выполнен!", "username", user.getUsername()));
    }

    // === ОФОРМЛЕНИЕ ЗАКАЗА ===
    @PostMapping("/orders")
    public ResponseEntity<?> createOrder(@RequestBody Map<String, Object> body) {
        try {
            Order order = new Order();
            order.setCustomerName((String) body.get("name"));
            order.setPhone((String) body.get("phone"));
            order.setAddress((String) body.get("address"));

            // Сохраняем весь список товаров как строку
            order.setItemsJson(body.get("items").toString());

            order.setTotalPrice(((Number) body.get("total")).doubleValue());

            orderRepository.save(order);
            return ResponseEntity.ok(Map.of("message", "Заказ успешно сохранен!"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", "Ошибка: " + e.getMessage()));
        }
    }
}